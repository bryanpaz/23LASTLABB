/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javapaz;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JAVAPAZ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double M;
        double C;
        double R;
        Scanner m = new Scanner(System.in);
        System.out.println("Ingresa M");
        M=m.nextInt();
        Scanner c = new Scanner(System.in);
        System.out.println("Ingresa C");
        C=c.nextInt();
        R=M+C/2;
        System.out.println("R es igual a"+" "+R);
    }
    
}
