/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cantidadesnumericas;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class CantidadesNumericas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int cant1;
        int cant2;
        Scanner c1=new Scanner(System.in);
        System.out.println("Ingresa la primera cantidad");
        cant1=c1.nextInt();
        Scanner c2=new Scanner(System.in);
        System.out.println("Ingresa la segunda cantidad");
        cant2=c2.nextInt();
        if(cant1>cant2){
            System.out.println(cant2+" , "+cant1);
        }else{
            System.out.println(cant1+" , "+cant2);
        }
    }
    
}
